There are 6 classes here:

Adaboost ( for adaboost algorithm)
Bagging  (for bagging algorithm)
Instance (for storing one training instance)
Machine  (call the methods in other classes)
SVM       ( for SMO algorithm)
SVM_Preprocessor  ( for preprocessing the data)


The main() method is in class Machine.


Notes:
The user cann't transfer any command line parameters to the method. 
If the user want to use these classes, please change the main() method of Machine class.
These classes and methods are very convinient to be used. 