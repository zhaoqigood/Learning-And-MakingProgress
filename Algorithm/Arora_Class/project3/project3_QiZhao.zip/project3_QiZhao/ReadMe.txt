For each input_Size of the box types ranging from size 100 to size 100000,
This program will calculate tallest height of the box stack.
It will output the inputsize, height and running time.
The input arrays are randomly initialized.

you can run this program either in an IDE environment or the Command line.